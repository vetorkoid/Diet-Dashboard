<?php

// Deleting rows from the users today food list

include 'config/config.php';
session_start();
$username = $_SESSION['username'];

if(isset($_POST['delete'])){//deleting an entry

  $number = $_POST['rows'];
  
  foreach($number as $items){
    $sql = "SELECT * FROM todayslist WHERE username = '$username' AND number = $items"; 
    $result = $conn->query($sql);
    $count = mysqli_num_rows($result);
  
    if($count > 1 ){
      $sql = "DELETE FROM todayslist WHERE username = '$username' AND number = $items LIMIT 1";
      $result = $conn->query($sql);
    }else{
    $sql = "DELETE FROM todayslist WHERE username = '$username' AND number = $items"; 
    $result = $conn->query($sql);
    }
  }
  header("Location: DDB.html");
  $conn->close();
  exit;
      
}

if(isset($_POST['alldelete'])){//deleting all from list
      $sql = "DELETE FROM todayslist WHERE username = '$username'";
      $result = $conn->query($sql);
  header("Location: DDB.html");
  $conn->close();
  exit;

      
}



?>