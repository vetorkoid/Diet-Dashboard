<?php

// Login functionality

include 'config/config.php';
if(isset($_POST['submit'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

    $exist = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($conn, $exist);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
    $count = mysqli_num_rows($result);
    if($username == '' || $password == ''){
        $message = "Please enter a username AND password before loging in.";
        echo "<script>alert('$message');</script>";
}elseif($count != 1){
        $message = "This user does not exist or your username/password is incorrect. Consider Signing up.";
        echo "<script>alert('$message');</script>";
    }else{
        header("Location: DDB.html");

        session_start();
        $_SESSION['username'] = $username;
    }
$conn ->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="styleSheets/LoginStyle.css">
</head>

<header>

<img src="styleSheets/images/logo2.png" alt="DDB Logo" class="logo">

        <h1>D i e t ~ D a s h B o a r d</h1>
        <p class = slogan><i>♡ Every Bite Counts: Let's Make Them Count Together ♡</i></p><br>

    </header>

<body>

    <div id = "form">

        <h1>Login to your account</h1>
        <p style='color:grey;'>Fill in the fields to login</p>
        <form action = LoginPage.php name ="form" method = "POST">
        <label>Username: </label></br>
        <input type ="text" id = "username" name="username"></br></br>
        <label>Password: </label></br>
        <input  type="password"  id = "password" name="password"></br></br>
        <input type ="submit" id = "button" value="Login" name="submit"></br>
        <p>Dont have an account? <a href="SignupPage.php"> Sign up</a></p>
</form>
</div>
</body>
</html>