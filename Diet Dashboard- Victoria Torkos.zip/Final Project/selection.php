<?php

// After a selection is made users can delete
// their chosen rows or add them to their todays list

include 'config/config.php';
session_start();
$username = $_SESSION['username'];

if(isset($_POST['delete'])){//deleting an entry

  $number = $_POST['rows'];

  foreach($number as $items){
    $sql = "DELETE FROM foodlist WHERE username = '$username' AND number = $items"; 
    $result = $conn->query($sql);
    $sql = "DELETE FROM todayslist WHERE username = '$username' AND number = $items"; 
    $result = $conn->query($sql);
  }

  //shifting values up after deletion
  $sql = "SELECT * FROM foodlist WHERE username = '$username'"; 
  $result1 = $conn->query($sql);
  $count = mysqli_num_rows($result1);

  for($i = 0; $i < $count; $i++){
    $result1->data_seek($i);
    $row = mysqli_fetch_array($result1, MYSQLI_ASSOC);
    $current = $row['number'];

    $sql = "UPDATE foodlist SET number = $i WHERE username = '$username' AND number = $current ";
    $result = $conn->query($sql);
    $sql = "UPDATE todayslist SET number = $i WHERE username = '$username' AND number = '$current' ";
    $result = $conn->query($sql);
}
header("Location: DDB.html");
$conn->close();
exit;
}

if(isset($_POST['add'])){//adding to todays list 

  $sql = "SELECT * FROM todayslist WHERE username = '$username'"; 
  $result1 = $conn->query($sql);
  $count = mysqli_num_rows($result1);

  $number = $_POST['rows'];

  foreach($number as $items){
    $sql = "SELECT * FROM foodlist WHERE username = '$username' AND number = '$items'"; 
    $result1 = $conn->query($sql);
    $row = mysqli_fetch_array($result1, MYSQLI_ASSOC);

    $foodname = $row['foodname'];
    $cal = $row['calories'];
    $fat = $row['fat'];
    $carb = $row['carb'];
    $protein = $row['protein'];
    
    $sql = "INSERT INTO todayslist (username, foodname, calories, fat, carb, protein, number) VALUES ('$username',  '$foodname', '$cal', '$fat', '$carb', '$protein', '$items')";
    $result = $conn->query($sql);
  }
  header("Location: DDB.html");
  $conn->close();
  exit;
}
?>
