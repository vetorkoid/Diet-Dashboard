<?php

//Getting the data for the pie chart 
//from the database and sending it back as an array

include 'config/config.php';
session_start();
$username = $_SESSION['username'];

$fatTotal = 0;
$carbTotal = 0;
$proTotal = 0;

$sql = "SELECT * FROM todayslist WHERE username = '$username'";
$result1 = $conn->query($sql);
$count1 = mysqli_num_rows($result1);

for ($i = 0; $i < $count1; $i++) {
    $result1->data_seek($i);
    $row1 = $result1->fetch_assoc();
    $fatTotal += $row1['fat'];
    $carbTotal += $row1['carb'];
    $proTotal += $row1['protein'];
}
$data = array('fat' => $fatTotal, 'carb' => $carbTotal, 'pro' => $proTotal);
echo json_encode($data);
?>