<?php

// Displaying the today content

include 'config/config.php';
session_start();
$username = $_SESSION['username'];

// Style for the Today content
echo "
<style>
body{
  font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
}
table{
  border-collapse: collapse;
  width: 800px;
  margin: 0 auto;
}
th, td {
  padding: 5px;
  text-align: center;
  height: 25px;
}
.top-row {
  height: 50px;
  background-color: #9dc39f; 
  font-weight: bold;
}
.normal-row {
  background-color: #f2f2f2;
}
hr{
  border: 0; 
  height: 2px; 
  background-color: #52714b; 
  margin: 20px 0;  
}
.fullTableBG{
  background-color: #639665;
  padding-left: 20px;
  border-radius: 20px;
}
.heading {
  width: 800px;
  text-align: center; 
}
.title {
  text-align: center;
  font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
  font-size: 35px;
}
.update {
  text-align: center;
  font-size: 20px;
}
.text {
  text-align: center;
  font-size: 15px;
  line-height: 0.1; 
  font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
}
.define {
  font-size: 15px;
  line-height: 0.1; 
  font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif; 
}
.subContainer {
  display: flex;
  align-items: center;
  padding-right: 10px; 
}
.subtitle {
  display: flex;
  align-items: center;
  padding-right: 10px; 
  font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
}
label {
  font-size: 15px;
  font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
}
input[type=submit]{
  background-color: #9dc39f;
  color: rgb(0, 0, 0);
  border: none;
  border-radius: 10px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  width: auto;
  height: 30px;
  font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
  font-size: 15px;
  font-weight: bold;
}
input[type=submit]:hover {
  background-color:#cfe9d1; 
}
input[type=number]{
  width: 10%;
}
tr:nth-child(even) {
  background-color: #dcefef;
}
.centered {
    display: flex;
    justify-content: center; 
    align-items: center;
    width: 100%;
}
</style>";


// TODAY LIST TITLE 
echo"
<h2 class = title><u>Today's Food List</u></h2>
<p class = text>View and delete from list with the below inputs. Changes will be reflected in the full table after submission.</p>
<hr>
";

// VIEW TODAY FOOD LIST TABLE
echo"
<div class = fullTableBG>
         </br><table id=fullTable >
            <tr class=top-row>
              <th>Row Number</th>
              <th>Food Name</th>
              <th>Calories</th>
              <th>Fat (g)</th>
              <th>Carbohydrate (g)</th>
              <th>Protein (g)</th>
            </tr>";

  $sql = "SELECT * FROM todayslist WHERE username = '$username'"; 
  $result = $conn->query($sql);
  $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
  $count = mysqli_num_rows($result);
    for($i = 0; $i < $count; $i++){
        $result->data_seek($i);
        $row = $result->fetch_assoc();
        echo" 
            <tr class=normal-row>
              <th id=number>". $row['number']."</th>
              <th id=foodname>". $row['foodname']."</th>
              <th id=cal>". $row['calories']."</th>
              <th id=fat>". $row['fat']."</th>
              <th id=carb>". $row['carb']."</th>
              <th id=protein>". $row['protein']."</th>
            </tr>";
  }

// CALCULATING THE TOTAL AND DISPLAYING IT IN A TABLE
    $calTotal =0;    
    $fatTotal =0;
    $carbTotal =0;
    $proTotal =0;

    $sql = "SELECT * FROM todayslist WHERE username = '$username'"; 
    $result1 = $conn->query($sql);
    $count1 = mysqli_num_rows($result1);

    for($i = 0; $i < $count1; $i++){
      $result1->data_seek($i);
      $row1 = $result1->fetch_assoc();
      $calTotal = $calTotal + $row1['calories'];
      $fatTotal = $fatTotal + $row1['fat'];
      $carbTotal = $carbTotal + $row1['carb'];
      $proTotal = $proTotal + $row1['protein'];
    }

echo"
</table></br>
    <table id=calc >
    <tr class=top-row>
      <th></th>
      <th>Calories</th>
      <th>Fat (g)</th>
      <th>Carbohydrate (g)</th>
      <th>Protein (g)</th>
    </tr>
    <tr class=normal-row>
      <th class=top-row>TOTAL MACROS:</th>
      <th id = fatty>$calTotal</th>
      <th id = fatty>$fatTotal</th>
      <th id = carby>$carbTotal</th>
      <th id = proy>$proTotal</th>
    </tr>
    </table></br></div><hr>";

//ROW SELECTION
    echo"
    <div class = subContainer>
    <h3 class = subtitle><u>REMOVE A ROW:</u></h3>
    <p class = text>select all rows by checking the corresponding box then use the DELETE to remove them from this list </p>
    </div>
    <form  action=deleteTdy.php name =form method = POST >";
          for($i = 0; $i < $count1; $i++){
            $result->data_seek($i);
            $row = $result->fetch_assoc();
      echo"<input type=checkbox  id=rows[] name=rows[] value=".$row['number'].">".$row['number']."";
    }

echo"  
    </br><p class = define><input type=submit id=delete value=Delete name=delete class=actionButton/></p>
    <hr>";
echo"  
    <div class=centered><input type=submit id=alldelete value='CLEAR  TABLE' name=alldelete /></div>
    </form></div></br></br>";
?>