<?php

// Displaying the foodlist content

include 'config/config.php';
session_start();
$username = $_SESSION['username'];

// Style associated with the content
echo "
<style>
body{
  font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
}
table{
  border-collapse: collapse;
  width: 800px;
  margin: 0 auto;
}
th, td {
  padding: 5px;
  text-align: center;
  height: 40px;
}
.top-row {
  height: 50px;
  background-color: #9dc39f; 
  font-weight: bold;
}
.normal-row {
  background-color: #f2f2f2;
}
hr{
  border: 0; 
  height: 2px; 
  background-color: #52714b; 
  margin: 20px 0;  
}
.fullTableBG{
  background-color: #639665;
  padding-left: 20px;
  border-radius: 20px;
}
.heading {
  width: 800px;
  text-align: center; 
}
.title {
  text-align: center;
  font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
  font-size: 35px;
}
.update {
  text-align: center;
  font-size: 20px;
}
.text {
  text-align: center;
  font-size: 15px;
  line-height: 0.1; 
  font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
}
.define {
  font-size: 15px;
  line-height: 0.1; 
  font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif; 
}
.subContainer {
  display: flex;
  align-items: center;
  padding-left: 30px; 
}
.subtitle {
  display: flex;
  align-items: center;
  padding-right: 10px; 
  font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
}
label {
  font-size: 15px;
  font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
}
input[type=submit]{
  background-color: #9dc39f;
  color: rgb(0, 0, 0);
  border: none;
  border-radius: 10px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  width: auto;
  height: 30px;
  font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
  font-size: 15px;
  font-weight: bold;
}
input[type=submit]:hover {
  background-color:#cfe9d1; 
}
input[type=number]{
  width: 10%;
}
tr:nth-child(even) {
  background-color: #dcefef;
}
</style>
";

// FOODLIST TITLE AND VIEW FULL TBALE
echo"
<h2 class = title><u>$username's Food List</u></h2>
<p class = text>View and adjust your table with the below inputs. Changes will be reflected in the full table after submission.</p>
<hr>";

// VIEW FULL TBALE
echo"
<div class = fullTableBG>

         </br><table id=fullTable >
            <tr class=top-row >
              <th>Row Number</th>
              <th>Food Name</th>
              <th>Calories</th>
              <th>Fat</th>
              <th>Carbohydrate</th>
              <th>Protein</th>
            </tr>";

    $sql = "SELECT * FROM foodlist WHERE username = '$username'"; 
    $result = $conn->query($sql);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
    $count = mysqli_num_rows($result);

    for($i = 0; $i < $count; $i++){
        $result->data_seek($i);
        $row = $result->fetch_assoc();
       echo" 
            <tr class=normal-row>
            <th id=number>".$row['number']."</th>
              <th id=foodname>". $row['foodname']."</th>
              <th id=cal>". $row['calories']."</th>
              <th id=fat>". $row['fat']." g</th>
              <th id=carb>". $row['carb']." g</th>
              <th id=protein>". $row['protein']." g</th>
            </tr>";
    }
echo"</table></br></div><hr>";

//ROW SELECTION
echo"
<div class = subContainer>
<h3 class = subtitle><u>ROW SELECTION:</u></h3>
<p class = text>select all rows by checking the corresponding box then use either button </p>
</div>
<div class = subContainer>
<form  action=selection.php name =form method = POST >";
      for($i = 0; $i < $count; $i++){
        $result->data_seek($i);
        $row = $result->fetch_assoc();
  echo"
  <input type=checkbox  id=rows[] name=rows[] value=".$row['number'].">".$row['number']."
  ";}
  echo"  
  </br></br><input type=submit id=delete value='Delete from Foodlist' name=delete class=actionButton/>    OR
  <input type=submit id=add value='Add to Todays Food List' name=add class=actionButton/>
  </form></div></br><hr>";

// ADD TO FOODLIST
echo"
<div class = subContainer>
<h3 class = subtitle><u>ADD TO YOUR FOOD LIST:</u></h3>
<p class = text>use the below input table to add to you food list</p>
</div>
<div class = subContainer>
      <form  action=add.php name =form method = POST >
      <label>Food Name: </label><input type=text placeholder=ex:Potato id=foodnameIN name=foodnameIN size=10/>
      <label>Calories: </label><input type=number placeholder=ex:150 id=calIN name=calIN size=10/>
      <label>Fat: </label><input type=number min=0 placeholder=ex:0 id=fatIN name=fatIN size=5 />
      <label>Carbohydrate: </label><input type=number min=0 placeholder=ex:26 id=carbIN name=carbIN size=5 />
      <label>Protein: </label><input type=number min=0 placeholder=ex:3 id=proteinIN name=proteinIN size=5/></br></br>
      <input type=submit id=submit value=ADD name=submit class=actionButton/>
</form></div></br><hr>";

// EDIT A ROW 
echo"
<div class = subContainer>
<h3 class = subtitle><u>EDIT A ROW:</u></h3>
<p class = text>enter the corresponding Row Number of the row you would like to modify, fill in the values, and submit</p>
</div>
<div class = subContainer>
<form  action=edit.php name =form method = POST >
      <label style='color:red;'>Row Number: </label><input type=number min=-1 placeholder=ex:1 id=numE name=numE size=5 /></br></br>
      <label>Food Name: </label><input type=text placeholder=ex:Potato id=foodnameE name=foodnameE size=10/>
      <label>Calories: </label><input type=number placeholder=ex:150 id=calE name=calE size=10/>
      <label>Fat: </label><input type=number min=0 placeholder=ex:0 id=fatE name=fatE size=5 />
      <label>Carbohydrate: </label><input type=number min=0 placeholder=ex:26 id=carbE name=carbE size=5/>
      <label>Protein: </label><input type=number min=0 placeholder=ex:3 id=proteinE name=proteinE size=5/></br></br>
      <input type=submit id=edit value=EDIT name=edit class=actionButton/>
</form></div></br><hr></br></br>";
?>
