<?php

// Adding the users inputs into the database

include 'config/config.php';

session_start();
$username = $_SESSION['username'];

if(isset($_POST['submit'])){
    $foodname = $_POST['foodnameIN'];
    $cal = $_POST['calIN'];
    $fat = $_POST['fatIN'];
    $carb = $_POST['carbIN'];
    $protein = $_POST['proteinIN'];

  if($foodname == '' ||  $cal == '' || $fat == '' || $carb == '' || $protein == ''){
    $message = "Please fill in all fields before adding to your Food List";
    echo "<script>alert('$message'); window.location.href = 'DDB.html';</script>";
  }else{
    $sql = "SELECT * FROM foodlist WHERE username = '$username'"; 
    $result = $conn->query($sql);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
    $count = mysqli_num_rows($result);

    $sql = "INSERT INTO `foodlist` (`username`, `foodname`, `calories`, `fat`, `carb`, `protein`, `number`) VALUES ('$username',  '$foodname', '$cal', '$fat', '$carb', '$protein', '$count')";
    $result = $conn->query($sql);

  header("Location: DDB.html");
  $conn->close();
  exit;

      
}}
?>