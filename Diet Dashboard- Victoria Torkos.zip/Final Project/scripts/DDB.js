
//Loading foodlist function
function loadTable(event) {
  event.preventDefault();

  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
     document.getElementById("info").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "foodlist.php", true);
  xhttp.send();

}

//Loading Todays list function
function loadToday(event) {
  event.preventDefault();

  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
     document.getElementById("info").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "today.php", true);
  xhttp.send();

}

//Clearing a div Function
function clearDiv(divId) {
  var div = document.getElementById(divId);
  if (div) {
      var elements = div.querySelectorAll('*');
  
      elements.forEach(function(element) {
          element.style.display = 'none'; 
      });
  } else {
      console.error("Div with id '" + divId + "' not found.");
  }
}

//Making chart div visible
function toggleVisibility() {
  var div = document.getElementById('chartId');
      div.style.display = 'block'; // Show the div
}
//Making chart div invisible
function toggleInvis() {
  var div = document.getElementById('chartId');
      div.style.display = 'none'; // Show the div
}

//Getting the data to make the pie chart and making/displaying the chart
function fetchData() {
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
      if (xhr.readyState === 4 && xhr.status === 200) {
          var responseData = JSON.parse(xhr.responseText);
          var fat = responseData.fat;
          var carb = responseData.carb;
          var pro = responseData.pro;
          createPieChart(fat, carb, pro);
      }
  };
  xhr.open('GET', 'chart.php', true);
  xhr.send();
}

// The function that creates the pie chart
function createPieChart(fat, carb, pro) {
  var xValues = ["Fat", "Carbohydrate", "Protein"];
  var yValues = [fat, carb, pro];
  var barColors = [
      "#9dc3a6",
      "#9dc3bf",
      "#c5cd9a"
  ];
  new Chart("myChart", {
      type: "pie",
      data: {
          labels: xValues,
          datasets: [{
              backgroundColor: barColors,
              data: yValues
          }]
      }
  });
}