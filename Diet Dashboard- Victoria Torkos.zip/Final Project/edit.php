<?php

// Updating the changes the user makes for the desired row

include 'config/config.php';
session_start();
$username = $_SESSION['username'];

if(isset($_POST['edit'])){

    $number = $_POST['numE'];

    $foodname = $_POST['foodnameE'];
    $cal = $_POST['calE'];
    $fat = $_POST['fatE'];
    $carb = $_POST['carbE'];
    $protein = $_POST['proteinE'];

if($number == ''|| $foodname == '' || $cal == '' ||  $fat == '' || $carb =='' || $protein == ''){
    $message = "Please fill in all fields before editing to your Food List";
    echo "<script>alert('$message'); window.location.href = 'DDB.html';</script>";
    
}else{
    $sql = "UPDATE foodlist SET foodname = '$foodname', calories = '$cal', fat = '$fat', carb = '$carb', protein = '$protein' WHERE username = '$username' AND number = '$number' ";
    $result = $conn->query($sql);
    
    $sql = "UPDATE todayslist SET foodname = '$foodname', calories = '$cal', fat = '$fat', carb = '$carb', protein = '$protein' WHERE username = '$username' AND number = '$number' ";
    $result = $conn->query($sql);

  header("Location: DDB.html");
  $conn->close();
  exit;     

}}
?>